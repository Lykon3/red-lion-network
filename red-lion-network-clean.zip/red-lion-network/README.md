# Red Lion Network

An open-source investigation exposing the architecture, actors, and operations behind the Red Lion influence ecosystem.

Maintained by: **M&LE.1+H&AI**

See `/docs/PRIMER.md` to get started.
