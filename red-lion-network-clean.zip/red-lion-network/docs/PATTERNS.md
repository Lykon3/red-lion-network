---
title: "Pattern Recognition: Influence Operation Detection"
---

[Extracted pattern section from TIMELINE.md]